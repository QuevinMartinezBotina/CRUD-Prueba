<?php

namespace App\Controllers;

use App\Models\Singer;


class SingerController extends BaseController
{




    public function index()
    {
        $response = array('error' => false, 'message' => 'ok', 'data' => []);

        $singers = new Singer();
        $data = $singers->findAll();

        header('Content-Type: application/json');

        $response['data'] = $data; //*La info de mi base de datos se manda en JSON
        echo json_encode($response);

        exit;
    }
    public function store()
    {
        header('Content-Type: application/json');

        $json = file_get_contents('php://input');
        $request = json_decode($json, TRUE);
        if (!isset($request['name'])) {
            http_response_code(400);
            echo json_encode('error');
            exit;
        } else if (trim($request['name']) == '') {
            http_response_code(400);
            echo json_encode('error');
            exit;
        }


        echo json_encode($request['name']);
        exit;
    }

    public function update()
    {
        return view('welcome_message');
    }

    public function destroy()
    {
        return view('welcome_message');
    }

    public function getSinger($id)
    {

        try {
            //code...
            $response = array('error' => false, 'message' => 'ok', 'data' => []);

            $singer = new Singer();
            $id = intval($id);
            /* var_dump($id);
            exit; */
            $data = $singer->where('singer_id', $id)->first(); //*Buscamos por el id

            if (empty($data)) {
                $response['error'] = true;
                $response['message'] = 'EL cantante no existe';

                http_response_code(404);
                echo json_encode($response);
                exit;
            }

            header('Content-Type: application/json');

            $response['data'] = $data; //*La info de mi base de datos se manda en JSON

            echo json_encode($response);
        } catch (\Throwable $th) {
            echo $th->getmessage();
        }

        exit;
    }

    public function show()
    {
        return view('welcome_message');
    }
}
